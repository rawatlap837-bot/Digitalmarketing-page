import { useState } from 'react'
import C from './content'

const T = ({ children }) => String(children).split(/(\[[^\]]+\])/).map((s, i) =>
  s.startsWith('[') ? <mark key={i} className="bg-cta/15 text-cta rounded px-1">{s}</mark> : s)

const btnCls = 'inline-flex items-center justify-center min-h-[48px] px-7 py-3 rounded-xl font-bold text-ink bg-cta hover:bg-ctaHover shadow-[0_0_32px_rgba(250,204,21,.35)] transition-colors duration-200'
const Btn = ({ href = '#lead', children, className = '' }) => <a href={href} className={`${btnCls} ${className}`}>{children}</a>
const Ghost = ({ href, children }) => <a href={href} className="inline-flex items-center justify-center min-h-[48px] px-7 py-3 rounded-xl border border-line text-main hover:border-cta transition-colors duration-200">{children}</a>

const Item = ({ s }) => {
  const m = s.match(/^(.+?[.:])\s(.+)$/)
  return m ? <><b className="text-main">{m[1]}</b> <T>{m[2]}</T></> : <T>{s}</T>
}

const Sec = ({ id, h, alt, children }) => (
  <section id={id} className={`py-16 lg:py-[120px] ${alt ? 'bg-surf/70' : ''}`}>
    <div className="mx-auto max-w-[1200px] px-5 sm:px-8 lg:px-10">
      <h2 className="text-[30px] lg:text-[42px] leading-tight max-w-3xl mb-10 lg:mb-12">{h}</h2>
      {children}
    </div>
  </section>
)

const Block = ({ b, alt }) => (
  <Sec id={b.id} h={b.h} alt={alt}>
    {b.p && b.p.map((t, i) => <p key={i} className="text-muted max-w-3xl mb-5"><T>{t}</T></p>)}
    {b.l && <ul className="grid gap-4 md:grid-cols-2 mt-6">{b.l.map((t, i) =>
      <li key={i} className="flex gap-3 bg-surf border border-line rounded-2xl p-5 hover:border-accent/60 transition-colors duration-200">
        <span aria-hidden="true" className="shrink-0 w-[22px] h-[22px] rounded-full bg-accent/15 text-accent grid place-items-center text-sm">✓</span>
        <span className="text-muted"><Item s={t} /></span></li>)}</ul>}
    {b.chips && <ul className="flex flex-wrap gap-3">{b.chips.split(' | ').map(t => <li key={t} className="px-4 py-2 rounded-full border border-line bg-surf text-main">{t}</li>)}</ul>}
    {b.after && b.after.map((t, i) => <p key={i} className="text-muted max-w-3xl mt-8"><Item s={t} /></p>)}
  </Sec>
)

function Lead({ id }) {
  const [v, setV] = useState({ name: '', phone: '', email: '', status: '' })
  const [err, setErr] = useState({})
  const [done, setDone] = useState(false)
  const check = () => {
    const e = {}
    if (!v.name.trim()) e.name = 'Please enter your full name.'
    if (!/^\+?[0-9\s-]{10,14}$/.test(v.phone.trim())) e.phone = 'Please enter a phone number with digits only.'
    if (!/^\S+@\S+\.\S+$/.test(v.email.trim())) e.email = 'Please enter a valid email address, for example name@email.com.'
    if (!v.status) e.status = 'Please choose your current status.'
    return e
  }
  const submit = (ev) => { ev.preventDefault(); const e = check(); setErr(e)
    // TODO: send `v` to your backend, Google Sheet or WhatsApp API here.
    if (!Object.keys(e).length) setDone(true) }
  const F = 'w-full min-h-[48px] rounded-xl bg-surf2 border border-line px-4 text-main placeholder:text-muted'
  if (done) return (
    <div className="bg-surf border border-line rounded-2xl p-8" aria-live="polite">
      <h3 className="text-[28px] mb-3">{C.form.thanksH}</h3>
      <p className="text-muted mb-6">{C.form.thanksP}</p>
      <Btn href="#lead">{C.form.thanksBtn}</Btn>
    </div>)
  const fld = (k, label, type = 'text') => (
    <div><label htmlFor={`${id}-${k}`} className="block text-sm mb-1">{label}</label>
      <input id={`${id}-${k}`} type={type} value={v[k]} onChange={e => setV({ ...v, [k]: e.target.value })} className={F} />
      <p className="text-bad text-sm min-h-[0px]" aria-live="polite">{err[k]}</p></div>)
  return (
    <form onSubmit={submit} noValidate className="bg-surf border border-line rounded-2xl p-6 sm:p-8 grid gap-4 shadow-[0_12px_40px_rgba(124,92,255,.18)]">
      <h3 className="text-[24px]">{C.form.h}</h3>
      {fld('name', 'Full name')}{fld('phone', 'Phone or WhatsApp', 'tel')}{fld('email', 'Email', 'email')}
      <div><label htmlFor={`${id}-status`} className="block text-sm mb-1">Current status</label>
        <select id={`${id}-status`} value={v.status} onChange={e => setV({ ...v, status: e.target.value })} className={F}>
          <option value="">Select</option>{C.form.status.map(s => <option key={s}>{s}</option>)}</select>
        <p className="text-bad text-sm" aria-live="polite">{err.status}</p></div>
      <button type="submit" className={btnCls}>{C.form.btn}</button>
      <p className="text-muted text-sm">{C.form.priv}</p>
    </form>)
}

export default function App() {
  const { hero, roadmap, tools, invest, risk, faq, final } = C
  return (<>
    <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 bg-cta text-ink px-3 py-2 rounded z-50">Skip to content</a>
    <header className="sticky top-0 z-40 h-16 md:h-[72px] backdrop-blur border-b border-line bg-ink/60">
      <nav aria-label="Main" className="mx-auto max-w-[1200px] h-full px-5 sm:px-8 lg:px-10 flex items-center justify-between">
        <span className="font-head font-bold text-2xl"><T>{C.brand}</T></span>
        <div className="hidden md:flex gap-8 text-muted text-[15px]">
          <a href="#roadmap" className="hover:text-main">Roadmap</a><a href="#tools" className="hover:text-main">Tools</a><a href="#faq" className="hover:text-main">FAQ</a></div>
        <Btn className="!min-h-[44px] !py-2 !px-5 text-sm">{hero.b1}</Btn>
      </nav>
    </header>
    <main id="main">
      <section className="relative overflow-hidden py-14 lg:py-[100px]">
        <div aria-hidden="true" className="absolute -top-20 -left-20 w-80 h-80 rounded-full bg-accent/30 blur-[120px]" />
        <div aria-hidden="true" className="absolute top-40 right-0 w-72 h-72 rounded-full bg-cyan/20 blur-[120px]" />
        <div className="relative mx-auto max-w-[1200px] px-5 sm:px-8 lg:px-10 grid lg:grid-cols-[1.15fr_.85fr] gap-12 items-start">
          <div>
            <p className="inline-block text-sm font-semibold text-accent bg-accent/15 rounded-full px-4 py-1 mb-6">{hero.eye}</p>
            <h1 className="text-[40px] lg:text-[60px] leading-[1.05] mb-6">{hero.h}</h1>
            <p className="text-muted max-w-xl mb-8">{hero.sub}</p>
            <div className="flex flex-wrap gap-4 mb-4"><Btn>{hero.b1}</Btn><Ghost href="#lead">{hero.b2}</Ghost></div>
            <p className="text-muted text-sm mb-8"><T>{hero.micro}</T></p>
            <ul className="flex flex-wrap gap-3">{hero.trust.map(t => <li key={t} className="px-4 py-2 rounded-full border border-line bg-white/[.06] backdrop-blur text-sm font-semibold">{t}</li>)}</ul>
          </div>
          <Lead id="hero" />
        </div>
      </section>

      <Block b={C.blocks[0]} alt /><Block b={C.blocks[1]} /><Block b={C.blocks[2]} alt /><Block b={C.blocks[3]} /><Block b={C.blocks[4]} alt />

      <Sec id="roadmap" h={roadmap.h}>
        <ol className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{roadmap.items.map(([m, t, d, b]) =>
          <li key={m} className="bg-surf border border-line rounded-2xl p-6 hover:border-accent/60 transition-colors duration-200">
            <p className="text-cyan font-semibold">{m}</p>
            <h3 className="text-[22px] my-2">{t}</h3>
            <p className="text-muted mb-4">{d}</p>
            <p className="text-sm bg-cta/10 border border-cta/30 rounded-lg px-3 py-2"><b className="text-cta">You build:</b> {b}</p></li>)}</ol>
      </Sec>

      <Sec id="tools" h={tools.h} alt>
        <ul className="flex flex-wrap gap-3 mb-6">{tools.list.split(' | ').map(t => <li key={t} className="px-4 py-2 rounded-xl border border-line bg-surf2 text-main">{t}</li>)}</ul>
        <p className="text-muted">{tools.note}</p>
      </Sec>

      {C.blocks2.map((b, i) => <Block key={b.id} b={b} alt={i % 2 === 1} />)}

      <Sec id="invest" h={invest.h} alt>
        <ul className="grid gap-4 md:grid-cols-3 mb-6">{invest.fees.split(' | ').map(f => <li key={f} className="bg-surf border border-line rounded-2xl p-6 text-[20px] font-semibold"><T>{f}</T></li>)}</ul>
        <p className="text-muted mb-3">{invest.inc}</p>
        <p className="mb-8"><T>{invest.urg}</T></p>
        <Btn>{invest.btn}</Btn>
        <div className="mt-12 bg-surf border border-line rounded-2xl p-6 max-w-3xl">
          <h3 className="text-[22px] mb-2">{risk.h}</h3><p className="text-muted"><T>{risk.p}</T></p></div>
      </Sec>

      <Sec id="faq" h="Frequently Asked Questions">
        <div className="max-w-3xl grid gap-3">{faq.map(([q, a], i) =>
          <details key={q} open={i === 0} className="bg-surf border border-line rounded-2xl p-5">
            <summary className="font-semibold text-main">{q}</summary>
            <p className="text-muted mt-3"><T>{a}</T></p></details>)}</div>
      </Sec>

      <section id="lead" className="py-16 lg:py-[120px]">
        <div className="mx-auto max-w-[1200px] px-5 sm:px-8 lg:px-10 grid lg:grid-cols-2 gap-12 items-center">
          <div className="rounded-3xl p-8 lg:p-12 bg-gradient-to-br from-accent/30 to-cyan/20 border border-line">
            <h2 className="text-[30px] lg:text-[42px] leading-tight mb-5"><T>{final.h}</T></h2>
            <p className="text-muted mb-8">{final.p}</p>
            <Btn href="#lead">{final.btn}</Btn>
            <p className="text-muted text-sm mt-5"><T>{final.below}</T></p>
          </div>
          <Lead id="foot" />
        </div>
      </section>
    </main>
    <footer className="border-t border-line bg-surf py-8 text-center text-muted text-sm"><T>{C.brand}</T></footer>
    <div className="md:hidden fixed bottom-0 inset-x-0 z-40 p-3 bg-ink/90 backdrop-blur border-t border-line">
      <Btn className="w-full">{hero.b1}</Btn></div>
  </>)
}
