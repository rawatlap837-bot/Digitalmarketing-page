export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: { ink: '#0B0D14', surf: '#12151F', surf2: '#1A1E2B', line: '#272C3D', main: '#F3F4F8', muted: '#9AA1B5', accent: '#7C5CFF', cyan: '#22D3EE', ok: '#34D399', bad: '#F87171',
      cta: '#FACC15', ctaHover: '#FDE047' },
    fontFamily: { head: ['Space Grotesk', 'sans-serif'], body: ['Inter', 'sans-serif'] }
  } },
  plugins: []
}
